import AppBar from '@material-ui/core/AppBar';
import Button from '@material-ui/core/Button';
import Drawer from '@material-ui/core/Drawer';
import Hidden from '@material-ui/core/Hidden';
import Icon from '@material-ui/core/Icon';
import IconButton from '@material-ui/core/IconButton';
import Toolbar from '@material-ui/core/Toolbar';
import withReducer from 'app/store/withReducer';
import clsx from 'clsx';
import React, { useRef, useState } from 'react';
import { DragDropContext, Droppable } from 'react-beautiful-dnd';
import { useDispatch, useSelector } from 'react-redux';
import { Link, withRouter, useParams } from 'react-router-dom';
import { useDeepCompareEffect } from '@fuse/hooks';
import * as Actions from '../store/actions';
import reducer from '../store/reducers';
import BoardAddList from './BoardAddList';
import BoardList from './BoardList';
import BoardTitle from './BoardTitle';
import BoardCardDialog from './dialogs/card/BoardCardDialog';
import BoardSettingsSidebar from './sidebars/settings/BoardSettingsSidebar';

function Board(props) {
	const dispatch = useDispatch();
	const board = useSelector(({ scrumboardApp }) => scrumboardApp.board);

	const routeParams = useParams();
	const containerRef = useRef(null);
	const [settingsDrawerOpen, setSettingsDrawerOpen] = useState(false);

	useDeepCompareEffect(() => {
		dispatch(Actions.getBoard(routeParams));
		return () => {
			dispatch(Actions.resetBoard());
		};
	}, [dispatch, routeParams]);

	function onDragEnd(result) {
		const { source, destination } = result;

		// dropped nowhere
		if (!destination) {
			return;
		}

		// did not move anywhere - can bail early
		if (source.droppableId === destination.droppableId && source.index === destination.index) {
			return;
		}

		// reordering list
		if (result.type === 'list') {
			dispatch(Actions.reorderList(result));
		}

		// reordering card
		if (result.type === 'card') {
			dispatch(Actions.reorderCard(result));
		}
	}

	function toggleSettingsDrawer(state) {
		setSettingsDrawerOpen(state === undefined ? !settingsDrawerOpen : state);
	}

	if (!board) {
		return null;
	}

	return (
		<div className="flex flex-1 flex-auto flex-col w-full h-full relative" ref={containerRef}>
			<AppBar position="static" color="primary">
				<Toolbar className="flex items-center justify-between px-4 sm:px-24 h-64 sm:h-96 container">
					<Hidden xsDown>
						<Button
							to="/apps/scrumboard/boards/"
							component={Link}
							variant="contained"
							color="secondary"
							className="normal-case"
						>
							<Icon>assessment</Icon>
							<span className="px-8">Boards</span>
						</Button>
					</Hidden>

					<Hidden smUp>
						<IconButton color="inherit" to="/apps/scrumboard/boards/" component={Link}>
							<Icon>assessment</Icon>
						</IconButton>
					</Hidden>

					<div className="flex flex-1 justify-center items-center">
						<BoardTitle />
					</div>

					<IconButton color="inherit" onClick={() => toggleSettingsDrawer(true)}>
						<Icon>settings</Icon>
					</IconButton>
				</Toolbar>
			</AppBar>

			<div className={clsx('flex flex-1 overflow-x-auto overflow-y-hidden')}>
				<DragDropContext onDragEnd={onDragEnd}>
					<Droppable droppableId="list" type="list" direction="horizontal">
						{provided => (
							<div ref={provided.innerRef} className="flex container py-16 md:py-24 px-8 md:px-12">
								{board.lists.map((list, index) => (
									<BoardList key={list.id} list={list} index={index} />
								))}
								{provided.placeholder}

								<BoardAddList />
							</div>
						)}
					</Droppable>
				</DragDropContext>
			</div>

			<Drawer
				anchor="right"
				className="absolute overflow-hidden"
				classes={{
					paper: 'absolute w-320'
				}}
				BackdropProps={{
					classes: {
						root: 'absolute'
					}
				}}
				container={containerRef.current}
				ModalProps={{
					keepMounted: true
				}}
				open={settingsDrawerOpen}
				onClose={() => toggleSettingsDrawer(false)}
			>
				<BoardSettingsSidebar />
			</Drawer>

			<BoardCardDialog />
		</div>
	);
}

export default withReducer('scrumboardApp', reducer)(withRouter(Board));
